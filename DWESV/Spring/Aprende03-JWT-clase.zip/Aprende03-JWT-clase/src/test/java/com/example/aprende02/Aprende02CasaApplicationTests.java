package com.example.aprende02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aprende02CasaApplicationTests {

	@Test
	void contextLoads() {
	}

}
