package com.daw2.aprende02.auth.models;

public enum RoleEnum {
  ROLE_ADMIN,
  ROLE_USER,
  ROLE_EMPLEADO

}
