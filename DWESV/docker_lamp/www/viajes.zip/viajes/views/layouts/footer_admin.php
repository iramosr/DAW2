<div class="bg-footer border-top border-bottom py-1 px-4 mt-4"  >
    &copy; Desarrollo de Aplicaciones WEB
</div>