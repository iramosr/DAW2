<!doctype html>
<html lang="es">
<?php require_once 'views/layouts/head_admin.php'; ?>
<body class="bg-light">
<?php require_once 'views/layouts/header_admin.php'; ?>

<div class="container bg-white">

    <h2>Editar Usuario</h2>

    <?php require_once 'views/admin/usuarios/form.php'; ?>

</div>

<?php require_once 'views/layouts/footer_admin.php'; ?>
</body>
</html>
