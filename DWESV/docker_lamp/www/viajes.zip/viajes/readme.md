# Proyecto viajes
## Ismael Ramos
- Existen 2 usuarios creados, admin y emple cuyas contraseñas son admin y emple respectivamente.
- En la página principal se puede ver una galeria de viajes seleccionados que siempre tendrán foto, y en la parte superior derecha se puede iniciar sesión o registrarse.
- Al registrarse se aplicará el rol de cliente y se iniciará sesión automaticamente
- Al iniciar sesion como cliente en la pagina ppal se podrá contratar un viaje directamente, también desde el apartado de viajes
- En el apartado de viajes se muestran los viajes con 2 botones, ver en detalle y mostrar descripcioón, además si el usuario es cliente se muestra un boton para contratar el viaje
- En el apartado de mis viajes se muestran los viajes contratados por el usuario, puede modificar la cantidad pagada, ver la contrtación en detalle, eliminarla o crear una nueva
- El apartado de administracion será visible para empleados y administradores contiene 3 apartados que permiten hacer un CRUD de usuarios, viajes y contrataciones
- Solo el administrador puede acceder al apartado de administracion de usuarios
- Ni el administrador ni el empleado pueden crear contrataciones