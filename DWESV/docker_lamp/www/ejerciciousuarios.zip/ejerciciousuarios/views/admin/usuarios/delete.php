<!doctype html>
<html lang="es">

<?php require_once 'views/layouts/head_main.php'; ?>

<body class="bg-light">
<?php require_once 'views/layouts/header_main.php'; ?>

<div class="container bg-white">



</div>

<?php require_once 'views/layouts/footer_main.php'; ?>
</body>
</html>