<div class="bg-footer">
    &copy; Desarrollo de Aplicaciones WEB
</div>