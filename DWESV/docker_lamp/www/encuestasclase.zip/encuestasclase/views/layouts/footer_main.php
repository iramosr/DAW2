<div class="bg-light">
    &copy; Desarrollo de Aplicaciones WEB
</div>