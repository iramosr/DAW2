<!doctype html>
<html lang="es">

<?php require_once 'views/layouts/head_main.php'; ?>

<body class="bg-light">
<?php require_once 'views/layouts/header_main.php'; ?>

<div class="container bg-white">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum ducimus, et eum nisi obcaecati quod, reiciendis
    repudiandae similique sint sunt, voluptas voluptates. Dolorum esse eum id ipsum optio. Quod, ut?
</div>

<?php require_once 'views/layouts/footer_main.php'; ?>
</body>
</html>