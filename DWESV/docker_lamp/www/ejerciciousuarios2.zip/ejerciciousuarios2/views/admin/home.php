<!doctype html>
<html lang="es">

<?php require_once 'views/layouts/head_admin.php'; ?>

<body class="bg-light">
<?php require_once 'views/layouts/header_admin.php'; ?>

<div class="container bg-white">
    <div class="py-1"></div>
    <div class="shadow-lg my-4 p-2 mt-2">
        <h3>ADMINISTRACIÓN</h3>
    </div>
    <div class="container bg-white">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum ducimus, et eum nisi obcaecati quod,
        reiciendis
        repudiandae similique sint sunt, voluptas voluptates. Dolorum esse eum id ipsum optio. Quod, ut?
    </div>
</div>
<?php require_once 'views/layouts/footer_admin.php'; ?>
</body>
</html>